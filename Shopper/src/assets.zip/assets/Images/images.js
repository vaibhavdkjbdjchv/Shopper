// src/assets/images.js
import Shirt from "./mensshirt.webp";
import Shirt2 from "./mensshirt1.webp";
import Shirt3 from "./mensshirt2.webp";
import Shirt4 from "./mensshirt3.webp";
import Shirt5 from "./mensshirt4.webp";
import Shirt6 from "./mensshirt5.webp";
import pents1 from "./pents1.webp";
import pents2 from "./pents2.webp";
import pents3 from "./pents3.webp";
import pents4 from "./pents4.webp";
import pents5 from "./pents5.webp";
import Shoes1 from "./shoes1.webp";
import Shoes1 from "./shoes1.webp";
import Shoes2 from "./shoes2.webp";
import Shoes3 from "./shoes3.webp";
import Shoes4 from "./shoes4.webp";
import Shoes5 from "./shoes5.webp";
import goggles1 from "./goggles1.webp";
import goggles2 from "./goggles2.webp";
import goggles3 from "./goggles3.webp";
import goggles4 from "./goggles4.webp";
import goggles5 from "./goggles5.webp";
import womens1 from "./womens1.webp";
import womens1 from "./womens1.webp";
import womens1 from "./womens1.webp";
import womens1 from "./womens1.webp";
import womens1 from "./womens1.webp";
import womens1 from "./womens1.webp";
import womens1 from "./womens1.webp";
import womens1 from "./womens1.webp";
import womens1 from "./womens1.webp";
import womens1 from "./womens1.webp";



const categoryImages = {
    Shirt,
    Shirt2,
    Shirt3,
    Shirt4,
    Shirt5,
    Shirt6,
    pents1,
    pents2,
    pents3,
    pents4,
    pents5,
    Shoes1,
    Shoes2,
    Shoes3,
    Shoes4,
    Shoes5
    Bags,
    Watches,
    Goggles
};

export default categoryImages;
